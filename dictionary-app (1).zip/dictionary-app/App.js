import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TextInput,
  TouchableOpacity,
  Alert,
  Image,
} from 'react-native';
import Constants from 'expo-constants';
import { Header } from 'react-native-elements';
import * as Speech from 'expo-speech';
import Component from 'react';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      word: '',
      definition: '',
    };
  }

  getWord = (word) => {
    var url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' + word;
    return fetch(url)
      .then((data) => {
        return data.json();
      })
      .then((response) => {
        var word = response[0].word;
        var definition = response[0].meanings[0].definitions[0].definition;
        this.setState({
          word: word.trim(),
          definition: definition.trim(),
        });
      });
  };

  speak = () => {
    var thingToSay = this.state.word;
    this.state.word === ''
      ? alert('Please Enter a word')
      : Speech.speak(thingToSay);
  };

  render() {
    return (
      <View style={styles.container}>
        <Header
          backgroundColor="lightblue"
          centerComponent={{
            text: 'Dictionary App',
            style: { color: 'black', fontWeight: 'bold' },
          }}></Header>
        <Image
          source={require('./assets/dictionary.png')}
          style={styles.iconImage}></Image>
        <TextInput
          style={styles.inputBox}
          onChangeText={(text) => {
            this.setState({
              text: text,
              isSearchedPressed: false,
              word: 'Loading....',
              lexicalCategory: '',
              examples: [],
              definition: '',
            });
          }}
        />
        <View>
          <TouchableOpacity
            style={styles.speakerContainer}
            onPress={this.speak}>
            <Image
              source={require('./SpeakerIcon.png')}
              style={{ height: 46, width: 46 }}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.searchButton}
            onPress={() => {
              this.setState({ isSearchedPressed: true });
              this.getWord(this.state.text);
            }}>
            <Text style={styles.searchText}> SEARCH </Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.text}>Word:  {this.state.word}</Text>
        <Text style={styles.text}>Definition:  {this.state.definition}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  speakerContainer: {
    backgroundColor: 'blue',
    flex: 0,
    marginLeft: 35,
    marginTop: 30,
  },
  iconImage: {
    width: '100%',
    height: '30%',
    resizeMode: 'contain',
    marginTop: 10,
  },
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  inputBox: {
    marginTop: 50,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    outline: 'none',
  },
  searchButton: {
    width: '50%',
    height: 40,
    alignSelf: 'center',
    padding: 10,
    marginLeft: 90,
    marginTop: 4,
    backgroundColor: '#0083ff',
  },
  searchText: {
    textAlign: 'center',
    fontSize: 25,
    fontWeight: 'bold',
    marginTop: -3,
  },
});
